import { recipesModel } from '@/models/recipes-model';
import { userModel } from '@/models/users-model';
import { replaceMongoIdInArray,replaceMongoIdInObject, restoreOriginalInput } from '@/utils/data-util';
import mongoose from 'mongoose';

async function getAllRecipes() {
  const allRecipes = await recipesModel.find().lean();
  return replaceMongoIdInArray(allRecipes);
}

async function getRecipesByCategory(category) {
  const allRecipes = await recipesModel
    .find({ category: restoreOriginalInput(category) })
    .lean();
  return replaceMongoIdInArray(allRecipes);
}


async function getRecipeByid(id) {
  const recipe = await recipesModel
    .findById({ _id: new mongoose.Types.ObjectId(id) })
    .lean();
  if (recipe) {
    return replaceMongoIdInObject(recipe);
  } else {
    throw new Error(`No recipe found with this ${id}`);
  }
}

async function createUser(user) {
  return await userModel.create(user);
}

async function findUserByCredentials(credentials) {
  const user = await userModel.findOne(credentials).lean();
  if (user) {
    return replaceMongoIdInObject(user);
  }
  return null;
}

async function updateFavourite({ recipeId, authId }) {
  const user = await userModel.findById({ _id: authId });

  if (user) {
    if (user.favourites.includes(recipeId)) {
      user.favourites.pull(recipeId);
    } else {
      user.favourites.push(recipeId);
    }
    user.save();
    
    return user.favourites;
  }
}

export {
  getAllRecipes,
  getRecipesByCategory,
  getRecipeByid,
  createUser,
  findUserByCredentials,
  updateFavourite,
};
