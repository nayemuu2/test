/* eslint-disable react/no-unescaped-entities */
import Image from 'next/image';
import Link from 'next/link';
import React from 'react';

function RecipeCard({ recipe }) {
  // console.log("recipe = ", recipe);

  const { name, rating, author, id } = recipe;

  return (
    <Link href={`/recipe/${id}`} className="car w-full">
      <div className="w-full aspect-[300/160] relative">
        <Image
          src="https://source.unsplash.com/-YHSwy6uqvk/300x160"
          className="rounded-md object-cover"
          alt=""
          fill
        />
      </div>
      ,<h4 className="my-2">{name}</h4>
      <div className="py-2 flex justify-between text-xs text-gray-500">
        <span>⭐️ {rating}</span>
        <span>{author}</span>
      </div>
    </Link>
  );
}

export default RecipeCard;
