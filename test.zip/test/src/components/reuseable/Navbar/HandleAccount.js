'use client';
import { useAuth } from '@/hooks/useAuth';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

function HandleAccount () {
  const { auth, setAuth } = useAuth();
  const router = useRouter();

  const logout = () => {
    setAuth(null);
    router.push('/login');
  };

  return (
    <div>
      {auth ? (
        <div className="py-2">
          <span className="mx-2">Hello, {auth?.firstName}</span>
          <span className="mx-1">|</span>
          <a className="cursor-pointer" onClick={logout}>
            Logout
          </a>
        </div>
      ) : (
        <Link href="/login">
          <li className="py-2 bg-[#eb4a36] px-6 rounded-md text-white content-center">
            Login
          </li>
        </Link>
      )}
    </div>
  );
};

export default HandleAccount;
