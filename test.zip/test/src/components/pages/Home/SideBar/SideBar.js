import { getAllRecipes } from '@/queries/queries';
import Link from 'next/link';
import React from 'react';

function removeSpacesKeepSpecialCharacters(inputString) {
  // Regular expression to match spaces
  var spaceRegex = /\s/g;
  // Replace spaces with dashes
  var stringWithoutSpaces = inputString.replace(spaceRegex, '-');
  return stringWithoutSpaces;
}

async function SideBar() {
  const allRecipes = await getAllRecipes();

  let categories = [];
  allRecipes.map((recipe) => {
    if (!categories.includes(recipe.category)) categories.push(recipe.category);
  });

  return (
    <div className="col-span-12 md:col-span-3">
      <h3 className="font-bold text-xl">Recipes</h3>
      <ul className="pl-2 my-6 space-y-4 text-gray-500 text-sm">
        {categories.map((category, index) => (
          <li key={index}>
            <Link href={`categorized/${category.split(' ').join('-')}`}>
              {category}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default SideBar;
