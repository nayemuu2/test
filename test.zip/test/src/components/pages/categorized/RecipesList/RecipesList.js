/* eslint-disable react/no-unescaped-entities */
import RecipeCard from '@/components/reuseable/RecipeCard/RecipeCard';
import { getRecipesByCategory } from '@/queries/queries';
import React from 'react';

async function RecipesList({ params }) {
  const allRecipes = await getRecipesByCategory(params);
  // console.log('allRecipes = ', allRecipes);
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 my-8 justify-items-center">
      {allRecipes.map((recipe) => (
        <RecipeCard recipe={recipe} key={recipe.id} />
      ))}
    </div>
  );
}

export default RecipesList;
