'use client';

import { useState } from 'react';

import { useRouter } from 'next/navigation';
import { useAuth } from '@/hooks/useAuth';
import { performLogin } from '@/actions';

function LoginForm() {
  const { setAuth } = useAuth();
  const router = useRouter();

  async function onSubmit(event) {
    event.preventDefault();
    try {
      const formData = new FormData(event.currentTarget);
      const found = await performLogin(formData);

      if (found) {
        setAuth(found);
        router.push('/');
      } else {
        window.alert('Please provide a valid login credential');
      }
    } catch (err) {
      window.alert(err.message);
    }
  }

  return (
    <form className="login-form" onSubmit={onSubmit}>
      <div>
        <label htmlFor="email">Email Address</label>
        <input type="email" name="email" id="email" />
      </div>

      <div>
        <label htmlFor="password">Password</label>
        <input type="password" name="password" id="password" />
      </div>


      <button
        type="submit"
        className="bg-[#eb4a36] py-3 rounded-md text-white w-full mt-4"
      >
        Login
      </button>
    </form>
  );
}

export default LoginForm;
