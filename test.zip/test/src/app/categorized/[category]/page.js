import RecipesList from '@/components/pages/categorized/RecipesList/RecipesList';
import Navbar from '@/components/reuseable/Navbar/Navbar';
import React from 'react';

function restoreOriginalInput(modifiedString) {
  // Regular expression to match dashes
  var dashRegex = /-/g;
  // Replace dashes with spaces
  var originalString = modifiedString.replace(dashRegex, ' ');
  // URL decode the string
  originalString = decodeURIComponent(originalString);
  return originalString;
}

function page({ params }) {
  //   console.log('params = ', params);

  return (
    <section className="container py-8">
      <div>
        <h3 className="font-semibold text-xl">
          {restoreOriginalInput(params.category)}
        </h3>
        <RecipesList params={params.category} />
      </div>
    </section>
  );
}

export default page;
