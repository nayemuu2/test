import CardGallery from '@/components/pages/Home/CardGallery/CardGallery';
import HeroSection from '@/components/pages/Home/HeroSection/HeroSection';
import SideBar from '@/components/pages/Home/SideBar/SideBar';

export default function Home() {
  return (
    <div>
      <HeroSection />

      <section className="container py-8">
        <div className="grid grid-cols-12 py-4">
          <SideBar />
          <CardGallery />
        </div>
      </section>
    </div>
  );
}
