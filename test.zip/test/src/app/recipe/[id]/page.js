import CookingSteps from "@/components/pages/recipe/CookingSteps/CookingSteps";
import RecipeDetails from "@/components/pages/recipe/RecipeDetails/RecipeDetails";
import { getRecipeByid } from "@/queries/queries";

export async function generateMetadata({ params }) {
  const recipe = await getRecipeByid(params.id);

  return {
    title: recipe.name,
    description: recipe.description,
  };
}

async function DetailsPage({ params }) {
  const recipe = await getRecipeByid(params.id);

  return (
    <div>
      <RecipeDetails recipe={recipe} />
      {recipe?.steps ? <CookingSteps steps={recipe?.steps} /> : <></>}
    </div>
  );
}

export default DetailsPage;
