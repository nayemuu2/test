export const replaceMongoIdInArray = (array) => {
  const mappedArray = array
    .map((item) => {
      return {
        id: item._id.toString(),
        ...item,
      };
    })
    .map(({ _id, ...rest }) => rest);

  return mappedArray;
};

export const replaceMongoIdInObject = (obj) => {
  const { _id, ...updatedObj } = { ...obj, id: obj._id.toString() };
  return updatedObj;
};

export function restoreOriginalInput(modifiedString) {
  // Regular expression to match dashes
  var dashRegex = /-/g;
  // Replace dashes with spaces
  var originalString = modifiedString.replace(dashRegex, ' ');
  // URL decode the string
  originalString = decodeURIComponent(originalString);
  return originalString;
}
